﻿using DataAccessLayer;
using EntitiesLayer;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;


namespace webService.Controllers
{
    public class CharacterController : ApiController
    {
        DalManager m;
        public CharacterController()
        {
            m = new DalManager();
        }

        public List<Character> GetAllCharacters()
        {
            List<Character> list = new List<Character>();

            foreach (Character charac in m.GetCharacters("Select * from character"))
            {
                list.Add(charac);
            }
            return list;
        }

      /*  public Character GetCharacter(int id)
        {
            return new Character(m.GetCharacters("Select * from character")[id]);
        }*/

       
    }
}
