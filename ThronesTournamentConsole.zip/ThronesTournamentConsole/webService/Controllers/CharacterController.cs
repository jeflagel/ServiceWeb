﻿using BusinessLayer;
using DataAccessLayer;
using EntitiesLayer;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;


namespace webService.Controllers
{
    [RoutePrefix("api/character")]
    public class CharacterController : ApiController
    {
        ThronesTournamentManager m;
        public CharacterController()
        {
            m = new ThronesTournamentManager();
        }
        
        public List<Character> GetAllCharacters()
        {
            List<Character> list = new List<Character>();

            foreach (Character charac in m.GetCharacters())
            {
                list.Add(charac);
            }
            return list;
        }
       

        [Route("{id}")]
        public Character GetCharac(int id)
        {
            return m.GetCharac(id);
        }
        [Route("{id}/relations")]
       [HttpGet]

       public IDictionary<Character, RelationshipEnum> GetRelations(int id)
        {
            return m.GetRelations(id);
        }

    }
}
