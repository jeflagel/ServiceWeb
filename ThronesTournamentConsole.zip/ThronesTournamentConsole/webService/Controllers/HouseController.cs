﻿using DataAccessLayer;
using EntitiesLayer;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;

namespace webService.Controllers
{
    public class HouseController : ApiController
    {
        DalManager m;
        public HouseController()
        {
            m = new DalManager();
        }

        public IList<House> GetHouses()
        {
            IList<House> list = new List<House>();

            foreach (House elm in m.GetHouses("Select * from Houses"))
            {
                list.Add(elm);
            }
            return list;
        }
    }
}
