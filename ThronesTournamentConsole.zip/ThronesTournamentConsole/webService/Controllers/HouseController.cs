﻿using BusinessLayer;
using DataAccessLayer;
using EntitiesLayer;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;

namespace webService.Controllers
{
    [RoutePrefix("api/house")]
    public class HouseController : ApiController
    {
        ThronesTournamentManager m;
        public HouseController()
        {
            m = new ThronesTournamentManager();
        }

        public IList<House> GetHouses()
        {
            IList<House> list = new List<House>();

            foreach (House elm in m.GetHouses())
            {
                list.Add(elm);
            }
            return list;
        }


    }
}
