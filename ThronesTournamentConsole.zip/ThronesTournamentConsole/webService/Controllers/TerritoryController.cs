﻿using BusinessLayer;
using DataAccessLayer;
using EntitiesLayer;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;

namespace webService.Controllers
{
    public class TerritoryController : ApiController
    {
        ThronesTournamentManager m;
        public TerritoryController()
        {
            m = new ThronesTournamentManager();
        }

        public List<Territory> GetTerritories()
        {
            List<Territory> list = new List<Territory>();

            foreach (Territory ter in m.GetTerritories())
            {
                list.Add(ter);
            }
            return list;
        }
    }
}
