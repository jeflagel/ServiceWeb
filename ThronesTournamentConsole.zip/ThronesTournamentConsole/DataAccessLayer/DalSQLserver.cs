﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using EntitiesLayer;
using System.Data.SqlClient;
using System.Data;

namespace DataAccessLayer
{

    public class DalSQLserver : IDAL
    {
        private String _connectionString = @"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=H:\Service Web\ServiceWeb-master\ThronesTournamentConsole\dataBase.mdf;Integrated Security=True;Connect Timeout=30";

        public static DalSQLserver Instance { get; set; }

        public DalSQLserver()
        {
            Instance = this;
        }



        private DataTable SelectbydataAdapter(string request)
        {
            DataTable results = new DataTable();
            using (SqlConnection sqlConnection = new SqlConnection(_connectionString))
            {
                SqlCommand sqlCommand = new SqlCommand(request, sqlConnection);
                SqlDataAdapter sqlDataAdapter = new SqlDataAdapter(sqlCommand);
                sqlDataAdapter.Fill(results);

            }
            return results;
        }

        public IList<Character> GetCharacters(string request)
        {

            DataTable data = SelectbydataAdapter(request);
            IList<Character> characters = new List<Character>();

            foreach (DataRow row in data.Rows)
            {
                int pv = 0, brav = 0, crazy = 0;
                String fn = "", ln = "";
                RelationshipEnum relation = RelationshipEnum.FRIENDSHIP;
                try
                {
                    crazy = Convert.ToInt32(row["crazyness"]);
                    brav = Convert.ToInt32(row["bravoury"]);
                    pv = Convert.ToInt32(row["pv"]);
                    fn = row["firstname"].ToString();
                    ln = row["lastname"].ToString();
                    // relation = (RelationshipEnum)Enum.Parse(typeof(RelationshipEnum), sqlDataReader.GetString(5).ToUpper());
                    Character charac = new Character(brav, crazy, fn, ln, pv, relation);
                    characters.Add(charac);
                }
                catch (Exception e)
                {
                    Console.WriteLine("erreur lecture BDD");
                    Console.ReadLine();
                }


            }
            return characters;
        }

        public IList<House> GetHouses(string request)
        {
            DataTable data = SelectbydataAdapter(request);
            IList<House> house = new List<House>();

            foreach (DataRow row in data.Rows)
            {
                int id = 0, nbunit = 0;
                String name = "";
                try
                {
                    id = Convert.ToInt32(row["id"]);
                    nbunit = Convert.ToInt32(row["numberOfunits"]);
                    name = row["HouseName"].ToString();
                    IList<Character> ch = GetCharacters("Select * from Characters where house =" + id);
                    House h = new House(ch, name, nbunit);
                    house.Add(h);
                }
                catch (Exception e)
                {
                    Console.WriteLine("erreur lecture BDD");
                    Console.ReadLine();
                }


            }
            return house;
        }

        public IList<Territory> GetTerritories()
        {
            DataTable data = SelectbydataAdapter("Select * from Territories");
            IList<Territory> territory = new List<Territory>();

            foreach (DataRow row in data.Rows)
            {
                int id = 0, idH = 0;
                TerritoryType type = TerritoryType.LAND;
                try
                {
                    id = Convert.ToInt32(row["id"]);
                    idH = Convert.ToInt32(row["ownerId"]);
                    type = (TerritoryType)Enum.Parse(typeof(TerritoryType), row["territoryType"].ToString());

                    IList<House> h = GetHouses("Select * from Houses where id =" + idH);
                    Territory ter = new Territory(type, h[0]);
                    territory.Add(ter);
                }
                catch (Exception e)
                {
                    Console.WriteLine("erreur lecture BDD");
                    Console.ReadLine();
                }


            }
            return territory;
        }

        public IList<string> GetCaracteristics()
        {
            throw new NotImplementedException();
        }



    }

}
