﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using EntitiesLayer;
using System.Data.SqlClient;
using System.Data;

namespace DataAccessLayer
{

    public class DalSQLserver : IDAL
    {
        private String _connectionString = @"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=H:\Service Web\ServiceWeb-master\ThronesTournamentConsole\dataBase.mdf;Integrated Security=True;Connect Timeout=30";

        public static DalSQLserver Instance { get; set; }

        public DalSQLserver()
        {
            Instance = this;
        }



        private DataTable SelectbydataAdapter(string request)
        {
            DataTable results = new DataTable();
            using (SqlConnection sqlConnection = new SqlConnection(_connectionString))
            {
                SqlCommand sqlCommand = new SqlCommand(request, sqlConnection);
                SqlDataAdapter sqlDataAdapter = new SqlDataAdapter(sqlCommand);
                sqlDataAdapter.Fill(results);

            }
            return results;
        }

        public Character GetCharac(int id)
        {
            DataTable data = SelectbydataAdapter("Select * from Characters where id=" + id);
            Character charac = new Character();
            foreach (DataRow row in data.Rows)
            {
                int pv = 0, brav = 0, crazy = 0;
                String fn = "", ln = "";
                try
                {
                    crazy = Convert.ToInt32(row["crazyness"]);
                    brav = Convert.ToInt32(row["bravoury"]);
                    pv = Convert.ToInt32(row["pv"]);
                    id = Convert.ToInt32(row["id"]);
                    fn = row["firstname"].ToString();
                    ln = row["lastname"].ToString();
                    charac = new Character(id, brav, crazy, fn, ln, pv);
                }
                catch (Exception e)
                {
                    Console.WriteLine("erreur lecture BDD");
                    Console.ReadLine();
                }
            }
            return charac;
        }

        public IList<Character> GetCharacters()
        {

            DataTable data = SelectbydataAdapter("Select * from Characters");
            IList<Character> characters = new List<Character>();

            foreach (DataRow row in data.Rows)
            {
                int pv = 0, brav = 0, crazy = 0, id = 0;
                String fn = "", ln = "";
                try
                {
                    crazy = Convert.ToInt32(row["crazyness"]);
                    brav = Convert.ToInt32(row["bravoury"]);
                    pv = Convert.ToInt32(row["pv"]);
                    id = Convert.ToInt32(row["id"]);
                    fn = row["firstname"].ToString();
                    ln = row["lastname"].ToString();
                    Character charac = new Character(id, brav, crazy, fn, ln, pv);
                    characters.Add(charac);
                }
                catch (Exception e)
                {
                    Console.WriteLine("erreur lecture BDD");
                    Console.ReadLine();
                }


            }
            return characters;
        }

        public IList<Character> GetHabitant(int idh)
        {

            DataTable data = SelectbydataAdapter("Select * from Characters where house =" + idh);
            IList <Character> characters = new List<Character>();

            foreach (DataRow row in data.Rows)
            {
                int pv = 0, brav = 0, crazy = 0, id = 0;
                String fn = "", ln = "";
                try
                {
                    crazy = Convert.ToInt32(row["crazyness"]);
                    brav = Convert.ToInt32(row["bravoury"]);
                    pv = Convert.ToInt32(row["pv"]);
                    id = Convert.ToInt32(row["id"]);
                    fn = row["firstname"].ToString();
                    ln = row["lastname"].ToString();
                    Character charac = new Character(id, brav, crazy, fn, ln, pv);
                    characters.Add(charac);
                }
                catch (Exception e)
                {
                    Console.WriteLine("erreur lecture BDD");
                    Console.ReadLine();
                }


            }
            return characters;
        }

        public IList<House> GetHouses()
        {
            DataTable data = SelectbydataAdapter("Select * from Houses");
            IList<House> house = new List<House>();

            foreach (DataRow row in data.Rows)
            {
                int id = 0, nbunit = 0;
                String name = "";
                try
                {
                    id = Convert.ToInt32(row["id"]);
                    nbunit = Convert.ToInt32(row["numberOfunits"]);
                    name = row["HouseName"].ToString();
                    IList<Character> ch = GetHabitant(id);
                    House h = new House(id, ch, name, nbunit);
                    house.Add(h);
                }
                catch (Exception e)
                {
                    Console.WriteLine("erreur lecture BDD");
                    Console.ReadLine();
                }


            }
            return house;
        }


        public IList<House> GetHousesTerritory(int idh)
        {
            DataTable data = SelectbydataAdapter("Select * from Houses where id =" + idh);
            IList<House> house = new List<House>();

            foreach (DataRow row in data.Rows)
            {
                int id = 0, nbunit = 0;
                String name = "";
                try
                {
                    id = Convert.ToInt32(row["id"]);
                    nbunit = Convert.ToInt32(row["numberOfunits"]);
                    name = row["HouseName"].ToString();
                    IList<Character> ch = GetHabitant(id);
                    House h = new House(id, ch, name, nbunit);
                    house.Add(h);
                }
                catch (Exception e)
                {
                    Console.WriteLine("erreur lecture BDD");
                    Console.ReadLine();
                }


            }
            return house;
        }

        public IList<Territory> GetTerritories()
        {
            DataTable data = SelectbydataAdapter("Select * from Territories");
            IList<Territory> territory = new List<Territory>();

            foreach (DataRow row in data.Rows)
            {
                int id = 0, idH = 0;
                TerritoryType type = TerritoryType.LAND;
                try
                {
                    id = Convert.ToInt32(row["id"]);
                    idH = Convert.ToInt32(row["ownerId"]);
                    type = (TerritoryType)Enum.Parse(typeof(TerritoryType), row["territoryType"].ToString());

                    IList<House> h = GetHousesTerritory(idH);
                    Territory ter = new Territory(id, type, h[0]);
                    territory.Add(ter);
                }
                catch (Exception e)
                {
                    Console.WriteLine("erreur lecture BDD");
                    Console.ReadLine();
                }


            }
            return territory;
        }


        public IDictionary<Character, RelationshipEnum> GetRelations(int c)
        {
            DataTable data = SelectbydataAdapter("Select * from Relations where IdP1=" + c + "or IdP2=" + c);
            IDictionary<Character, RelationshipEnum> dico = new Dictionary<Character, RelationshipEnum>();
            foreach (DataRow row in data.Rows)
            {
                int idp2 = 0, idp1 = 0;
                RelationshipEnum rel;
                Character ch2;
                idp1 = Convert.ToInt32(row["IdP1"]);
                idp2 = Convert.ToInt32(row["IdP2"]);
                rel = (RelationshipEnum)Enum.Parse(typeof(RelationshipEnum), row["relation"].ToString());

                if (idp1== c)
                {
                    ch2= GetCharac(idp2);
                    dico.Add(ch2, rel);
                }
                else
                {
                    ch2 = GetCharac(idp1);
                    dico.Add(ch2, rel);
                }

            }
            return dico;

        }


        /*public IList<Fight> GetFight()
        {
            DataTable data = SelectbydataAdapter("Select * from Fight");
            foreach (DataRow row in data.Rows)
            {
                int idp2 = 0, idp1 = 0;
                RelationshipEnum rel;
                Character ch2;
                idp1 = Convert.ToInt32(row["IdP1"]);
                idp2 = Convert.ToInt32(row["IdP2"]);
                rel = (RelationshipEnum)Enum.Parse(typeof(RelationshipEnum), row["relation"].ToString());

                if (idp1 == c.id)
                {
                    ch2 = GetCharac(idp2);
                    c.AddRelatives(ch2, rel);
                }
                else
                {
                    ch2 = GetCharac(idp1);
                    c.AddRelatives(ch2, rel);
                }

            }

        }
        public IList<string> GetCaracteristics()
        {
            throw new NotImplementedException();
        }
        */


    }

}
