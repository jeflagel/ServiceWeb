﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using EntitiesLayer;

namespace DataAccessLayer
{
    public class DalManager : IDAL
    {
        DalSQLserver dalSQL = new DalSQLserver(); 
        public IList<string> GetCaracteristics()
        {
            return dalSQL.GetCaracteristics();
        }
        //string carac = "Select * from Characters";

        public IList<Character> GetCharacters(string carac)
        {
            return dalSQL.GetCharacters(carac);   
        }

        public IList<House> GetHouses(string request)
        {
            return dalSQL.GetHouses(request);
        }

        public IList<Territory> GetTerritories()
        {
            return dalSQL.GetTerritories();
        }
    }
}
