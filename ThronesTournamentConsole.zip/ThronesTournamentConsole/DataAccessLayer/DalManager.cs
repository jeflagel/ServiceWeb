﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using EntitiesLayer;

namespace DataAccessLayer
{
    public class DalManager 
    {
        IDAL dalSQL = new DalSQLserver();


        private static DalManager instance;
        private static readonly object padlock = new object();

        public static DalManager Instance
        {
            get
            {
                if(instance == null)
                {
                    lock (padlock)
                    {
                        if(instance == null)
                        {
                            instance = new DalManager();
                        }
                    }
                }
                return instance; 
            }
        }
      

        private DalManager()
        {
        }
        

        public IList<Character> GetCharacters()
        {
            return dalSQL.GetCharacters();   
        }

        public IList<House> GetHouses()
        {
            return dalSQL.GetHouses();
        }

        public IList<Territory> GetTerritories()
        {
            return dalSQL.GetTerritories();
        }

        public IDictionary<Character, RelationshipEnum> GetRelations(int c)
        {
            return  dalSQL.GetRelations(c);
        }
        public Character GetCharac(int id)
        {
            return dalSQL.GetCharac(id);
        }

    }
}
