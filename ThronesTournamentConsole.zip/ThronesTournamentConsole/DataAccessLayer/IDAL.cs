﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using EntitiesLayer;



namespace DataAccessLayer

{

    public interface IDAL

    {

        IList<House> GetHouses();

        IList<Territory> GetTerritories();

        IList<Character> GetCharacters();


        IDictionary<Character, RelationshipEnum> GetRelations(int id);
        Character GetCharac(int id);

        IList<House> GetHousesTerritory(int idh);


    }

}