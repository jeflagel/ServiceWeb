﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using EntitiesLayer;



namespace DataAccessLayer

{

    public interface IDAL

    {

        IList<House> GetHouses(string r);

        IList<Territory> GetTerritories();

        IList<Character> GetCharacters(string request);

        IList<String> GetCaracteristics();



    }

}