﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using EntitiesLayer;

namespace StubDataAccessLayer
{
    public class DalManager
    {
        private List<House> houses;
        private List<Territory> territories;
        private List<Character> characters;
        private List<String> caracteristics;

        public DalManager()
        {
            houses = new List<House>();
            territories = new List<Territory>();
            characters = new List<Character>();
            caracteristics = new List<String>();

            Character c1 = new Character(10, 20, "charlotte", "ze", 10, RelationshipEnum.FRIENDSHIP);
            Character c2 = new Character(10, 20, "gerard", "az", 20, RelationshipEnum.HATRED);
            Character c3 = new Character(10, 20, "louis", "azer", 45, RelationshipEnum.LOVE);
            Character c4 = new Character(10, 20, "jean", "reza", 2, RelationshipEnum.LOVE);
            Character c5 = new Character(10, 20, "elizabeth", "ti", 30, RelationshipEnum.RIVALRY);
            Character c6 = new Character(10, 20, "mickey", "titi", 14, RelationshipEnum.FRIENDSHIP);
            Character c7 = new Character(10, 20, "emma", "zera", 74, RelationshipEnum.HATRED);
            Character c8 = new Character(10, 20, "jeanne", "erea", 41, RelationshipEnum.LOVE);

            characters.Add(c1);
            characters.Add(c2);
            characters.Add(c3);
            characters.Add(c4);
            characters.Add(c5);
            characters.Add(c6);
            characters.Add(c7);
            characters.Add(c8);

            House h1 = new House(null, "nom 1", 100);
            House h2 = new House(null, "nom 2", 122);
            House h3 = new House(null, "nom 3", 92);
            House h4 = new House(null, "nom 4", 57);
            House h5 = new House(null, "nom 5", 170);

            houses.Add(h1);
            houses.Add(h2);
            houses.Add(h3);
            houses.Add(h4);
            houses.Add(h5);


            territories.Add(new Territory(TerritoryType.SEA, h1));
            territories.Add(new Territory(TerritoryType.MOUNTAIN, h2));
            territories.Add(new Territory(TerritoryType.DESERT, h3));
            territories.Add(new Territory(TerritoryType.LAND, h4));
            territories.Add(new Territory(TerritoryType.MOUNTAIN, h5));


            characters.Select(x => x.firstName + " " + x.lastName + " " + x.bravoury + " " + x.crazyness);
        }


        public List<House> getHouses(int unit=0)
        {
            return (List<House>) houses.Where(x => x.numberOfUnits>=unit);
        }

        public List<Territory> getTerritories()
        {
            return territories;
        }

        public List<Character> getCharacters()
        {
            return characters;
        }

        public List<String> getCaracteristics()
        {
            return (List<String>) characters.Select(x => x.firstName + " " + x.lastName + " " + x.bravoury + " " + x.crazyness);
        }



    }
}
