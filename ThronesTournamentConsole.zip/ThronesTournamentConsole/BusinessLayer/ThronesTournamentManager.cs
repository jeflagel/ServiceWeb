﻿using DataAccessLayer;
using EntitiesLayer;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BusinessLayer
{
    public class ThronesTournamentManager
    {
        DalManager dal = DalManager.Instance; 

        public IList<Character> GetCharacters()
        {
            return dal.GetCharacters();
        }
        public Character GetCharac(int id)
        {
            return dal.GetCharac(id);
        }
        public IDictionary<Character, RelationshipEnum> GetRelations(int id )
        {
            return dal.GetRelations(id);
        }
        public IList<House> GetHouses( )
        {
            return dal.GetHouses();
        }
        public IList<Territory> GetTerritories()
        {
            return dal.GetTerritories();
        }



    }
}
