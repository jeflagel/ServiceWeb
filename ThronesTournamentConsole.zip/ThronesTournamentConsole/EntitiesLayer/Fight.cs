﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EntitiesLayer
{
    public class Fight : EntityObject
    {
        private House houseChallenger1;
        private House houseChallenger2;
        private House winningHouse;


        public Fight(int idth, House h1, House h2)
        {
            id = idth;
            houseChallenger1 = h1;
            houseChallenger2 = h2;
            winningHouse = null; 
        }
        public Fight(int idth, House h1, House h2, House hw)
        {
            id = idth;
            houseChallenger1 = h1;
            houseChallenger2 = h2;
            winningHouse = hw;
        }
    }
}
