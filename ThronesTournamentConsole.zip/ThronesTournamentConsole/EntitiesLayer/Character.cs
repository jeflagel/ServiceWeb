﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EntitiesLayer
{
    public class Character : EntityObject
    {
        public int bravoury { get; set; }
        public int crazyness { get; set; }
        public String firstName { get; set; }
        public String lastName { get; set; }
        public int pv { get; set; }
        public CharacterTypeEnum type { get; set; }
        public IDictionary<Character, RelationshipEnum> Relationships { get; set; }

        public void AddRelatives(Character c, RelationshipEnum rel)
        {
            Relationships.Add(c, rel);
        }

        public void AddAllRelatives(IDictionary<Character, RelationshipEnum> dico)
        {
            this.Relationships = dico;
        }
        public Character()
        {
            Relationships = new Dictionary<Character, RelationshipEnum>() ;
        }

        public Character(Character charac)
        {
            this.id = charac.id;
            this.bravoury = charac.bravoury;
            this.crazyness = charac.crazyness;
            this.firstName = charac.firstName;
            this.lastName = charac.lastName;
            this.pv = charac.pv;
            Relationships = new Dictionary<Character, RelationshipEnum>();
        }

        public Character(int idth, int brav, int crazy, String fn, String ln, int pv)
        {
            id = idth;
            bravoury = brav;
            crazyness = crazy;
            firstName = fn;
            lastName = ln;
            this.pv = pv;
            Relationships = new Dictionary<Character, RelationshipEnum>();
        }

        public String toString()
        {
            return firstName + " " + lastName;
        }
    }

    public enum RelationshipEnum {FRIENDSHIP,LOVE,HATRED,RIVALRY }

    public enum CharacterTypeEnum { WARRIOR, WITCH, TACTICIAN, LEADER, LOSER }
}
