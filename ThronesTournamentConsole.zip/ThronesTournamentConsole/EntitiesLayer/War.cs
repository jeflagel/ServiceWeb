﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EntitiesLayer
{
    class War : EntityObject
    {
        public House house1 { get; set; }
        public House house2 { get; set; }
        public House winner { get; set; }
        public List<Fight> fights { get; set; }


        public War(int idth, House h1, House h2, House hw, List<Fight> f)
        {
            id = idth;
            house1 = h1;
            house2 = h2;
            winner = hw;
            fights = f;
        }

        public War(int idth, House h1, House h2)
        {
            id = idth;
            house1 = h1;
            house2 = h2;
            winner = null;
            fights = null;
        }
    }
}
