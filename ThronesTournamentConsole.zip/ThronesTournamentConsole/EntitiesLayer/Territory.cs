﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EntitiesLayer
{
    public class Territory : EntityObject
    {
        public TerritoryType type;
        public House owner { get; set; }

        public Territory(TerritoryType t, House o)
        {
            id = ids;
            ids += 1;
            type = t;
            owner = o;
        }
    }

    public enum TerritoryType { SEA, MOUNTAIN, LAND, DESERT }
}
