﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EntitiesLayer
{
    public class House : EntityObject
    {
        public IList<Character> Housers { get; set; }
        public String name { get; set; }
        public int numberOfUnits { get; set; }

        public void AddHousers(Character housers)
        {
            Housers.Add(housers);
        }

        public House()
        {
            id = ids;
            ids += 1;
            Housers = new List<Character>();
        }
        public House(IList<Character> chars, String name, int nb)
        {
            id = ids;
            ids += 1;
            Housers = chars;
            this.name = name;
            numberOfUnits = nb;
        }
        public House(String Name, int nb)
        {
            name = Name;
            numberOfUnits = nb;
        }

    }
}
