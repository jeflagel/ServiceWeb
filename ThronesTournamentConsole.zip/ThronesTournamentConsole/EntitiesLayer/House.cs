﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EntitiesLayer
{
    public class House : EntityObject
    {
        public IList<Character> Housers { get; set; }
        public String name { get; set; }
        public int numberOfUnits { get; set; }

        public void AddHousers(Character housers)
        {
            Housers.Add(housers);
        }

        public House(int idth)
        {
            id = idth;
            Housers = new List<Character>();
        }
        public House(int idth, IList<Character> chars, String name, int nb)
        {
            id = idth;
            Housers = chars;
            this.name = name;
            numberOfUnits = nb;
        }
        public House(int idth, String Name, int nb)
        {
            id = idth;
            name = Name;
            numberOfUnits = nb;
        }

    }
}
