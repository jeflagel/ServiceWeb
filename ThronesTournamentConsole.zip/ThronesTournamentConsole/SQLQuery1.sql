﻿
BEGIN
	/*Create table Characters (firstName varchar(50),lastName varchar(50),bravoury int, crazyness int, pv int, relationships varchar(30), characterType varchar(30) , house int);
	Insert into Characters values ( 'charlotte', 'ze',10, 20, 10, 'FRIENDSHIP','WITCH',1 );
	Insert into Characters values ('gerard', 'az',10, 20,  20, 'HATRED', 'LOSER',3);
	Insert into Characters values ( 'louis', 'azer',10, 20, 45, 'LOVE', 'WARRIOR',5);
	Insert into Characters values ( 'jean', 'reza',10, 20, 2, 'LOVE', 'LOSER',2);
	Insert into Characters values ( 'elizabeth', 'ti', 10, 20,30,'RIVALRY', 'TACTICIAN',1);
	Insert into Characters values ('mickey', 'titi',10, 20,  14, 'FRIENDSHIP', 'TACTICIAN',2);
	Insert into Characters values ( 'emma', 'zera',10, 20, 74, 'HATRED','LEADER',4);
	Insert into Characters values ( 'jeanne', 'erea', 10, 20,41, 'LOVE', 'LOSER',3);



	Create table Houses (id int,HouseName varchar(50), numberOfunits int);
	Insert into Houses values(1,'Amioldor',100);
	Insert into Houses values(2,'Elaramir',122);
	Insert into Houses values(3,'Torrion',92);
	Insert into Houses values(4,'Fyndir',57);
	Insert into Houses values(5,'Glithra',170);


	Create table Territories (id int, territoryType varchar(50), ownerId int);
	Insert into Territories values(1,'SEA',1);
	Insert into Territories values(2,'MOUNTAIN',5);
	Insert into Territories values(3,'DESERT',3);
	Insert into Territories values(4,'LAND',2);
	Insert into Territories values(5,'MOUNTAIN',4);
	Insert into Territories values(6,'SEA',3);
	Insert into Territories values(7,'MOUNTAIN',4);
	Insert into Territories values(8,'DESERT',1);
	Insert into Territories values(9,'LAND',4);
	Insert into Territories values(10,'MOUNTAIN',2);


	Create table Fights (id int, houseChallenger1Id int,houseChallenger2Id int, winningHouse int, war int);
	Insert into Fights values(1,2,3,2,1);
	Insert into Fights values(2,3,5,5,2);
	Insert into Fights values(3,4,1,4,3);
	Insert into Fights values(4,1,3,1,4);


	Create table Wars (id int, house1Id int,house2Id int, winner int);
	Insert into Wars values(1,2,3,2);
	Insert into Wars values(2,3,5,5);
	Insert into Wars values(3,4,1,4);
	Insert into Wars values(4,1,3,1);*/
	
END;
